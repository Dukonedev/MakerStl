<?php
require 'cors.php';
require 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

// GET ALL USERS (Admin)
if ($method === 'GET') {
    $stmt = $pdo->query("SELECT id, username, role, created_at FROM users");
    $users = $stmt->fetchAll();
    echo json_encode(['success' => true, 'users' => $users]);
}
// DELETE USER (Admin)
elseif ($method === 'POST' && isset($_GET['action']) && $_GET['action'] === 'delete') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? 0;

    if ($id) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing ID']);
    }
}
?>
