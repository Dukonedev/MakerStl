ISTRUZIONI INSTALLAZIONE LATO SERVER (Hosting)

1. Carica tutti i file `.php` contenuti in questo zip nella cartella pubblica del tuo sito (es. `public_html` o `www`).
2. Assicurati che il database `virtupri78616` esista e che le credenziali in `db.php` siano corrette (dovrebbero già esserlo).
3. Apri il browser e visita: `https://virtuprinto.com/setup.php` (sostituisci col dominio corretto se in sottocartella).
   - Questo creerà la tabella `users` e l'utente `admin` se non esistono.
4. Una volta fatto, l'App Desktop potrà connettersi usando questi script invece della connessione diretta MySQL (richiederà un aggiornamento dell'app).
