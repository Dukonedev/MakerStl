<?php // Silence is golden ?>
